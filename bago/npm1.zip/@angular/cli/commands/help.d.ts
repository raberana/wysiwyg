declare const HelpCommand: any;
export default HelpCommand;
