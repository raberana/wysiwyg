export default function (options: any): any;
