export declare function readTsconfig(tsconfigPath: string): any;
