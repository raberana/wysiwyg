export interface RenderUniversalTaskOptions {
    inputIndexPath: string;
    route: string;
    serverOutDir: string;
    outputIndexPath: string;
}
declare const _default: any;
export default _default;
