/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { COMMON_DIRECTIVES as ɵe } from './src/directives/index';
export { LocaleDataIndex as ɵc } from './src/i18n/locale_data';
export { findLocaleData as ɵd } from './src/i18n/locale_data_api';
export { DEPRECATED_PLURAL_FN as ɵa, getPluralCase as ɵb } from './src/i18n/localization';
export { COMMON_DEPRECATED_I18N_PIPES as ɵg } from './src/pipes/deprecated/index';
export { COMMON_PIPES as ɵf } from './src/pipes/index';
